<div class="postbox">
           <h3 class="hndle"><span><?php _e('Theme specific styling', 'framemarket'); ?></span></h3>
           <div class="inside">
			<span class="description">
				<?php _e('FrameMarket does not have styles built in please use a child theme', 'framemarket'); ?>
				</span>
</div>
</div>