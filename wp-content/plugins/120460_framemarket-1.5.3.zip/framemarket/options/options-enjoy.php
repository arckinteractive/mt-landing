<div class="postbox">
           <h3 class="hndle"><span><?php _e( 'Enjoy your theme - *save before leaving this page', 'framemarket'); ?></span></h3>
           <div class="inside">
			<a class="button" href="widgets.php">
			<?php _e('Add some widgets', 'framemarket'); ?>
				</a>
				<a class="button" href="edit.php">
				<?php _e('Add some posts', 'framemarket'); ?>
					</a>
							<a class="button" href="edit.php?post_type=page">
							<?php _e('Add some pages', 'framemarket'); ?>
								</a>
  </tbody></table>
</div>
</div>