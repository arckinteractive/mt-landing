<?php
global $bp_existed, $multi_site_on;

include( get_template_directory() . '/library/functions/conditional-functions.php' );
?>