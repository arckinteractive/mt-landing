Welcome to the Grid Market child theme for MarketPress.

To use this theme please also have the Frame-Market theme in your wp-content/themes.

1. Move Grid-Market/ from themes/ to wp-content/themes/

2. Make sure you have both Frame-Market/ and Grid-Market/ in your wp-content/themes folder.

3. Activate Grid-Market/ - this is the theme to use Frame-Market/ is just there as a parent theme.

4. Enjoy your theme.


120460-1376187715