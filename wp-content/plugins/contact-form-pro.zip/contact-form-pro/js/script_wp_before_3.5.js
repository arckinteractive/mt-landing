(function($){
	$(document).ready(function(){
		$('#cntctfrmpr_additions_options').change( function() {
			if($(this).is(':checked') )
				$('.cntctfrmpr_additions_block').removeClass('cntctfrmpr_hidden');
			else
				$('.cntctfrmpr_additions_block').addClass('cntctfrmpr_hidden');
		});
		$('#cntctfrmpr_style_options').change( function() {
			if($(this).is(':checked') )
				$('.cntctfrmpr_style_block').removeClass('cntctfrmpr_hidden');
			else
				$('.cntctfrmpr_style_block').addClass('cntctfrmpr_hidden');
		});
		$('#cntctfrmpr_change_label').change( function() {
			if($(this).is(':checked') )
				$('.cntctfrmpr_change_label_block').removeClass('cntctfrmpr_hidden');
			else
				$('.cntctfrmpr_change_label_block').addClass('cntctfrmpr_hidden');
		});
		$('#cntctfrmpr_display_add_info').change( function() {
			if($(this).is(':checked') )
				$('.cntctfrmpr_display_add_info_block').removeClass('cntctfrmpr_hidden');
			else
				$('.cntctfrmpr_display_add_info_block').addClass('cntctfrmpr_hidden');
		});
		$('#cntctfrmpr_add_language_button').click(function(){
			$.ajax({
				url: '../wp-admin/admin-ajax.php',//update_url,
				type: "POST",
				data: "action=cntctfrmpr_add_language&lang="+$('#cntctfrmpr_languages').val(),
				success: function(result) {
					var lang_val = $('#cntctfrmpr_languages').val();
					$('.cntctfrmpr_change_label_block .cntctfrmpr_language_tab, .cntctfrmpr_action_after_send_block .cntctfrmpr_language_tab').each(function(){
						$(this).addClass('hidden');
					});
					$('.cntctfrmpr_change_label_block .cntctfrmpr_language_tab').first().clone().appendTo(".cntctfrmpr_change_label_block").removeClass('hidden').removeClass('cntctfrmpr_tab_en').addClass('cntctfrmpr_tab_'+lang_val);
					$('.cntctfrmpr_action_after_send_block .cntctfrmpr_language_tab').first().clone().insertBefore("#cntctfrmpr_before").removeClass('hidden').removeClass('cntctfrmpr_tab_en').addClass('cntctfrmpr_tab_'+lang_val);
					$('.cntctfrmpr_change_label_block .cntctfrmpr_language_tab').last().find('input').each(function(){
						$(this).val('');
						$(this).attr('name', $(this).attr('name').replace('[en]', '['+lang_val+']'));
					});
					var text = $('.cntctfrmpr_change_label_block .cntctfrmpr_language_tab').last().find('.cntctfrmpr_info').last().text();
					text = text.replace('lang=en', 'lang='+lang_val);
					text = text.replace(' or [contact_form]', '');
					$('.cntctfrmpr_change_label_block .cntctfrmpr_language_tab').last().find('.cntctfrmpr_info').last().text(text);
					$('.cntctfrmpr_action_after_send_block .cntctfrmpr_language_tab').last().find('input').val('').attr('name', $('.cntctfrmpr_action_after_send_block .cntctfrmpr_language_tab').last().find('input').attr('name').replace('[en]', '['+lang_val+']'));
					text = $('.cntctfrmpr_change_label_block .cntctfrmpr_language_tab').last().find('.cntctfrmpr_info').last().text();
					text = text.replace('lang=en', 'lang='+lang_val);
					text = text.replace(' or [contact_form]', '');
					$('.cntctfrmpr_action_after_send_block .cntctfrmpr_language_tab').last().find('.cntctfrmpr_info').last().text(text);
					$('.cntctfrmpr_change_label_block .cntctfrmpr_label_language_tab, .cntctfrmpr_action_after_send_block .cntctfrmpr_label_language_tab').each(function(){
						$(this).removeClass('cntctfrmpr_active');
					});
					$('.cntctfrmpr_change_label_block .clear').prev().clone().attr('id','cntctfrmpr_label_'+lang_val).addClass('cntctfrmpr_active').html($('#cntctfrmpr_languages option:selected').text()+' <span class="cntctfrmpr_delete" rel="'+lang_val+'">X</span>').insertBefore('.cntctfrmpr_change_label_block .clear');
					$('.cntctfrmpr_action_after_send_block .clear').prev().clone().attr('id','cntctfrmpr_label_'+lang_val).addClass('cntctfrmpr_active').html($('#cntctfrmpr_languages option:selected').text()+' <span class="cntctfrmpr_delete" rel="'+lang_val+'">X</span>').insertBefore('.cntctfrmpr_action_after_send_block .clear');
					$('#cntctfrmpr_languages option:selected').remove();
				},
				error: function( request, status, error ) {
					alert( error + request.status );
				}
			});
		});
		$('.cntctfrmpr_change_label_block .cntctfrmpr_label_language_tab').live('click', function(){
			$('.cntctfrmpr_label_language_tab').each(function(){
				$(this).removeClass('cntctfrmpr_active');
			});
			var index = $('.cntctfrmpr_change_label_block .cntctfrmpr_label_language_tab').index($(this));
			$(this).addClass('cntctfrmpr_active');
			var blocks = $('.cntctfrmpr_action_after_send_block .cntctfrmpr_label_language_tab');
			$(blocks[index]).addClass('cntctfrmpr_active');
			$('.cntctfrmpr_language_tab').each(function(){
				$(this).addClass('hidden');
			});
			$('.'+this.id.replace('label', 'tab')).removeClass('hidden');
		});
		$('.cntctfrmpr_action_after_send_block .cntctfrmpr_label_language_tab').live('click', function(){
			$('.cntctfrmpr_label_language_tab').each(function(){
				$(this).removeClass('cntctfrmpr_active');
			});
			var index = $('.cntctfrmpr_action_after_send_block .cntctfrmpr_label_language_tab').index($(this));
			$(this).addClass('cntctfrmpr_active');
			var blocks = $('.cntctfrmpr_change_label_block .cntctfrmpr_label_language_tab')
			$(blocks[index]).addClass('cntctfrmpr_active');
			$('.cntctfrmpr_language_tab').each(function(){
				$(this).addClass('hidden');
			});
			console.log(this.id.replace('text', 'tab'), index);
			$('.'+this.id.replace('text', 'tab')).removeClass('hidden');
		});
		$('.cntctfrmpr_delete').live('click', function( event ){
			event.stopPropagation();
			if ( confirm( confirm_text ) ) {
				var lang = $(this).attr('rel');
				$.ajax({
					url: '../wp-admin/admin-ajax.php',//update_url,
					type: "POST",
					data: "action=cntctfrmpr_remove_language&lang="+lang,
					success: function(result) {
						$('.cntctfrmpr_active, .cntctfrmpr_tab_'+lang).each(function(){
							$(this).remove();
						});
						$('.cntctfrmpr_change_label_block .cntctfrmpr_label_language_tab').first().addClass('cntctfrmpr_active');
						$('.cntctfrmpr_action_after_send_block .cntctfrmpr_label_language_tab').first().addClass('cntctfrmpr_active');
						$('.cntctfrmpr_change_label_block .cntctfrmpr_language_tab').first().removeClass('hidden');
						$('.cntctfrmpr_action_after_send_block .cntctfrmpr_language_tab').first().removeClass('hidden');
					},						
					error: function( request, status, error ) {
						alert( error + request.status );
					}
				});
			}
		});
		$('.cntctfrmpr_help_box').mouseover(function(){
			$(this).children().css('display', 'block');
		});
		$('.cntctfrmpr_help_box').mouseout(function(){
			$(this).children().css('display', 'none');
		});

		$('#cntctfrmpr_show_errors_block').removeClass('hidden');
		var arr = ['name','address','email','phone','subject','message','attachment'];
		$.each( arr, function(index, value){
			if ( $("input[name='cntctfrmpr_tooltip_display_"+value+"']").is(':checked') ){ $('#cntctfrmpr_contact_'+value).next('.cntctfrmpr_help_box').removeClass('hidden'); }
			$("input:checkbox[name='cntctfrmpr_tooltip_display_"+value+"']").change(function(){
				if ( $(this).is(':checked') ){ $('#cntctfrmpr_contact_'+value).next('.cntctfrmpr_help_box').removeClass('hidden'); } 
				else { $('#cntctfrmpr_contact_'+value).next('.cntctfrmpr_help_box').addClass('hidden'); }
			});
		});
		if ( $("input[name='cntctfrmpr_tooltip_display_attachment']").is(':checked') ){ 
			$('#cntctfrmpr_contact_attachment').css('float','left'); 
			$('#cntctfrmpr_contact_attachment').siblings('label').css('display', 'none');
		};		
		$("input:checkbox[name='cntctfrmpr_tooltip_display_attachment']").change(function(){
			if ( $(this).is(':checked') ){
				$('#cntctfrmpr_contact_attachment').css('float','left'); 
				$('#cntctfrmpr_contact_attachment').siblings('label').css('display', 'none');
			} else { 
				$('#cntctfrmpr_contact_attachment').css('float','none');
				$('#cntctfrmpr_contact_attachment').siblings('label').css('display', 'block');
			};
		});

		$('#cntctfrmpr_show_errors').change(function(){
			$('#cntctfrmpr_contact_form input.text, #cntctfrmpr_contact_form textarea').removeAttr("style");
			if ( $(this).is(':checked') ){
				var error_displaying = $('select[name="cntctfrmpr_error_displaying"] option:selected').val();
				if ( error_displaying == 'labels') {
					$('.cntctfrmpr_error_text').removeClass('hidden');
					$('#cntctfrmpr_contact_form input.text, #cntctfrmpr_contact_form textarea').removeClass('cntctfrmpr_error');
				}
				if ( error_displaying == 'input_colors') {
					$('.cntctfrmpr_error_text').addClass('hidden');
					$('#cntctfrmpr_contact_form input.text, #cntctfrmpr_contact_form textarea').addClass('cntctfrmpr_error');
				}
				if ( error_displaying == 'both') {
					$('.cntctfrmpr_error_text').removeClass('hidden');
					$('#cntctfrmpr_contact_form input.text, #cntctfrmpr_contact_form textarea').addClass('cntctfrmpr_error');
				}
				$('.cntctfrmpr_help_box').addClass('cntctfrmpr_help_box_error');
			} else {
				$('.cntctfrmpr_error_text').addClass('hidden');
				$('#cntctfrmpr_contact_form input.text, #cntctfrmpr_contact_form textarea').removeClass('cntctfrmpr_error');
				$('.cntctfrmpr_help_box').removeClass('cntctfrmpr_help_box_error');
			}
		});
		$('select[name="cntctfrmpr_error_displaying"]').change(function(){
			if ( $('#cntctfrmpr_show_errors').is(':checked') ){
				var error_displaying = $('select[name="cntctfrmpr_error_displaying"] option:selected').val();
				if ( error_displaying == 'labels') {
					$('.cntctfrmpr_error_text').removeClass('hidden');
					$('#cntctfrmpr_contact_form input.text, #cntctfrmpr_contact_form textarea').removeClass('cntctfrmpr_error');
				}
				if ( error_displaying == 'input_colors') {
					$('.cntctfrmpr_error_text').addClass('hidden');
					$('#cntctfrmpr_contact_form input.text, #cntctfrmpr_contact_form textarea').addClass('cntctfrmpr_error');
				}
				if ( error_displaying == 'both') {
					$('.cntctfrmpr_error_text').removeClass('hidden');
					$('#cntctfrmpr_contact_form input.text, #cntctfrmpr_contact_form textarea').addClass('cntctfrmpr_error');
				}
			}
		});
		$(".cntctfrmpr_default").click(function(){
			var def = $(this).attr("id");
			$(this).parent().children('span').children('input').html(def);
			$(this).parent().children('span').children('input').val(def);
			$(this).parent().children('span').children('.minicolors-swatch').children('span').css('background-color', def );
			$(this).parent().children('.cntctfrmpr_colorPicker').val(def);
			$(this).parent().children('.cntctfrmpr_colorPicker').html(def);
			$(this).parent().children('.cntctfrmpr_colorPicker_small').css('background-color', def );
		});
		$(".cntctfrmpr_tooltip_label").click(function() {
			if ( $(this).parent().children('input').is(':checked') ){
				$(this).parent().children('input').prop('checked', false);
			}else{
				$(this).parent().children('input').prop('checked', true);
			};
		});   
		$('.cntctfrmpr_language_tab_block').css('display', 'none');
		$('.cntctfrmpr_language_tab_block_mini').css('display', 'block');
		
		$('.cntctfrmpr_language_tab_block_mini').live( 'click', function(){
			if( $('.cntctfrmpr_language_tab_block').css('display') == 'none' ) {
				$('.cntctfrmpr_language_tab_block').css('display', 'block');
				$('.cntctfrmpr_language_tab_block_mini').css('background-position', '1px -3px');
			}else{
				$('.cntctfrmpr_language_tab_block').css('display', 'none');
				$('.cntctfrmpr_language_tab_block_mini').css('background-position', '');
			}
		});

		$("input[name='cntctfrmpr_border_input_width']").blur(function(){
			var color = $(this).val();
			$('#cntctfrmpr_contact_form input.text, #cntctfrmpr_contact_form textarea').css("border-width", color+'px');
		});	

		$("input[name='cntctfrmpr_button_width']").blur(function(){
			var color = $(this).val();
			$('#cntctfrmpr_contact_form input[type=submit]').css("width", color);
		});
		
		$("span.cntctfrmpr_colorPicker_small").each(function(){
			var timer, color, flag = false;
		    $(this).click(function(){
		    	var this_click = $(this),
		        	this_click_id = $(this).prev().attr('id');
	         	timer = setInterval(function() {
		    	   	flag = true;
		    	   	color = this_click.prev().val();
		    	   	if ( this_click.prev().hasClass('color') ) {
		    	   		$(this_click_id).css("color", color);
		    	   	}
		    	   	if ( this_click.prev().hasClass('background_color') ) {
		    	   		$(this_click_id).css("background", color);
		    	   	}
		    	   	if ( this_click.prev().hasClass('border_color') ) {
		    	   		$(this_click_id).css("border-color", color);
		    	   	}
		    	   	if ( this_click.prev().hasClass('placeholder_color_error') ) {
		    	   			styleContent = '#cntctfrmpr_contact_form input.cntctfrmpr_error::-moz-placeholder, #cntctfrmpr_contact_form textarea.cntctfrmpr_error::-moz-placeholder {color: ' + color + ' !important;}	#cntctfrmpr_contact_form input.cntctfrmpr_error::-webkit-input-placeholder, #cntctfrmpr_contact_form textarea.cntctfrmpr_error::-webkit-input-placeholder {color: ' + color + ' !important;} #cntctfrmpr_contact_form input.cntctfrmpr_error:-ms-input-placeholder, #cntctfrmpr_contact_form textarea.cntctfrmpr_error:-ms-input-placeholder {color: ' + color + ' !important;} #cntctfrmpr_contact_form input.cntctfrmpr_error:-moz-placeholder, #cntctfrmpr_contact_form textarea.cntctfrmpr_error:-moz-placeholder {color: ' + color + ' !important;}',
							styleBlock = '<style id="cntctfrmpr_placeholder_error">' + styleContent + '</style>';
				    	$('head').append(styleBlock);
		    	   	}
		    	   	if ( this_click.prev().hasClass('placeholder_color') ) {
		    	   		styleContent = '#cntctfrmpr_contact_form input::-moz-placeholder, #cntctfrmpr_contact_form textarea::-moz-placeholder {color: ' + color + ' !important;} #cntctfrmpr_contact_form input::-webkit-input-placeholder, #cntctfrmpr_contact_form textarea::-webkit-input-placeholder {color: ' + color + ' !important;} #cntctfrmpr_contact_form input:-ms-input-placeholder, #cntctfrmpr_contact_form textarea:-ms-input-placeholder {color: ' + color + ' !important;} #cntctfrmpr_contact_form input:-moz-placeholder, #cntctfrmpr_contact_form textarea:-moz-placeholder {color: ' + color + ' !important;}',
						styleBlock = '<style id="cntctfrmpr_placeholder">' + styleContent + '</style>';
			    		$('head').append(styleBlock);
			    	}
		    	}, 500);
		    });
			$(".wrap").click(function(){
			    if( flag === true ){
			        flag = false;
			        clearInterval(timer);
			    }
			});
		});
		$(".cntctfrmpr_colorPicker").each(function(){
			var timer, color, flag = false;
		    $(this).click(function(){
		        var this_click = $(this),
		        	this_click_id = $(this).attr('id');
	         	timer = setInterval(function() {
					flag = true;
					color = this_click.val();
					if ( this_click.hasClass('color') ) {
						$(this_click_id).css("color", color);
					}
		    	   	if ( this_click.hasClass('background_color') ) {
		    	   		$(this_click_id).css("background", color);
		    	   	}
		    	   	if ( this_click.hasClass('border_color') ) {
		    	   		$(this_click_id).css("border-color", color);
		    	   	}
		    	   	if ( this_click.hasClass('placeholder_color_error') ) {
		    	   			styleContent = '#cntctfrmpr_contact_form input.cntctfrmpr_error::-moz-placeholder, #cntctfrmpr_contact_form textarea.cntctfrmpr_error::-moz-placeholder {color: ' + color + ' !important;}	#cntctfrmpr_contact_form input.cntctfrmpr_error::-webkit-input-placeholder, #cntctfrmpr_contact_form textarea.cntctfrmpr_error::-webkit-input-placeholder {color: ' + color + ' !important;} #cntctfrmpr_contact_form input.cntctfrmpr_error:-ms-input-placeholder, #cntctfrmpr_contact_form textarea.cntctfrmpr_error:-ms-input-placeholder {color: ' + color + ' !important;} #cntctfrmpr_contact_form input.cntctfrmpr_error:-moz-placeholder, #cntctfrmpr_contact_form textarea.cntctfrmpr_error:-moz-placeholder {color: ' + color + ' !important;}',
							styleBlock = '<style id="cntctfrmpr_placeholder_error">' + styleContent + '</style>';
				    	$('head').append(styleBlock);
		    	   	}
		    	   	if ( this_click.hasClass('placeholder_color') ) {
		    	   		styleContent = '#cntctfrmpr_contact_form input::-moz-placeholder, #cntctfrmpr_contact_form textarea::-moz-placeholder {color: ' + color + ' !important;} #cntctfrmpr_contact_form input::-webkit-input-placeholder, #cntctfrmpr_contact_form textarea::-webkit-input-placeholder {color: ' + color + ' !important;} #cntctfrmpr_contact_form input:-ms-input-placeholder, #cntctfrmpr_contact_form textarea:-ms-input-placeholder {color: ' + color + ' !important;} #cntctfrmpr_contact_form input:-moz-placeholder, #cntctfrmpr_contact_form textarea:-moz-placeholder {color: ' + color + ' !important;}',
						styleBlock = '<style id="cntctfrmpr_placeholder">' + styleContent + '</style>';
			    		$('head').append(styleBlock);
			    	}
		    	}, 500);
		    });
			$(".wrap").click(function(){
			    if( flag === true ){
			        flag = false;
			        clearInterval(timer);
			    };
			});
		});		
	});
})(jQuery);