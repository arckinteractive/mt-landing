﻿=== Contact Form Pro ===
Contributors: bestwebsoft
Donate link: https://www.2checkout.com/checkout/purchase?sid=1430388&quantity=10&product_id=13
Tags: Contact Form, text, contact, form, contacts, contact form, request, contact me, feedback form, feedback, contact button, contact form plugin, contacts form plugin, attachment, send, copy, attachment, send copy
Requires at least: 2.9
Tested up to: 3.6
Stable tag: 1.05
License: Proprietary
License URI: http://bestwebsoft.com/end-user-license-agreement/

Add Contact Form Pro to your WordPress website.

== Description ==

Contact Form Pro is the easy way to add a feedback form to the post or page.

<a href="http://support.bestwebsoft.com" target="_blank">Support</a>

= Features =

Contact Form
	* You can choose where to send the messages - this can be any user and any email address.
	* You can add the field for file attachment.
	* You can add the field for sending a copy of the message to the user who fills out the contact form. The copy will be sent to the email address specified while filling out the contact form.
	* You can change the field labels.
Contact Form Pro
	+ You can change the Contact Form CSS
	+ You can add a placeholder
	+ You can add tooltips for each field
	+ You can use JavaScript for the form validation with highlighting option 
	
= Translation =

* Arabic (ar) (thanks to Hammad Alshammari (ABU HATIM), www.abuhatim.net)
* Belarusian (be_BY) (thanks to <a href="mailto:nullbsd@gmail.com">Sakałoŭ Alaksiej</a>)
* Bulgarian (bg_BG) (thanks to Martin Jekov)
* European Portuguese (pt_PT) (thanks to <a href="mailto:cesarbsilva@gmail.com">César Silva</a>, www.clubetelemoveis.com )
* Brazilian Portuguese (pt_BR) (thanks to <a href="mailto:brenojac@gmail.com">Breno Jacinto</a>, www.iconis.org.br, <a href="mailto:wordpress@djio.com.br">DJIO</a>, www.djio.com.br)
* Catalan (ca) (thanks to <a href="mailto:kenneth@snollocer.net">Kenneth</a>)
* Czech (cs_CZ) (thanks to Petr Zápotocký)
* Danish (da_DK) (thanks to Mads Hannibal)
* Dutch (nl_NL) (thanks  to <a href="mailto:ronald@hostingu.nl">HostingU, Ronald Verheul</a>, Jan Boeijink, <a href="mailto:info@katchy.nl">Dorine Kat-Stronck</a>)
* Finnish (fi) (thanks to <a href="mailto:mikrotuki@sisuaxles.com">Mikrotuki</a>)
* French (fr_FR) (thanks to Alain Thomas and Vincent Cibelli and Capronnier Luc)
* Galician (gl_ES) (thanks to Paula Rios)
* German (de_DE) (thanks to Hartung Thomas)
* Greek (el_GR) (thanks to Pantelis Panteloglou)
* Hebrew (he_IL) (thanks to Sagive SEO)
* Hindi (hi_IN) (thanks to <a href="mailto:ash.pr@outshinesolutions.com">Team Outshine</a>)
* Hungarian (hu_HU) (thanks to <a href="mailto:karcsi1978@gmail.com">Karoly Kovacs</a>)
* Italian (it_IT) (thanks to <a href="mailto:ilian@ultra-violet.it">Ilian Gagliardi</a>)
* Japanese (ja) (thanks to Foken)
* Norwegian (nb_NO) (thanks to Tore Hjartland)
* Persian (fa_IR) (thanks to <a href="mailto:me@alirezaJamali.net">Alireza Jamali</a>, alirezajamali.net, <a href="mailto:akbari.mostafa@gmail.com">Mostafa Akbari Motlaq</a>)
* Polish (pl_PL) (thanks to Jarek Spirydowicz)
* Romanian (ro_RO) (thanks to George Bejan and Cosmin Berescu)
* Russian (ru_RU)
* Serbian (sr_RS) (thanks to Georgijevic Team, www.georgijevic.info)
* Spanish (es_ES) (thanks to Jesús Parra)
* Swedish (sv_SE) (thanks to Martin Tonek, <a href="mailto:joakim@limewoodmedia.com">Joakim Lindskog</a>, <a href="mailto:maarten@vandendriest.com">Maarten van den Driest</a> - www.crossanddot.nl)
* Turkish (tr_TR) (thanks to <a href="mailto:d-bulent@hotmail.com ">Devrim Bulent Ibis</a>, www.devrimhoca.com)
* Ukrainian (uk) (thanks to <a href="mailto:xxxxAndyxxxx@gmail.com">Andrew Yaschuk</a>)

If you create your own language pack or update the existing one, you can send <a href="http://codex.wordpress.org/Translating_WordPress" target="_blank">the text in PO and MO files</a> for <a href="http://support.bestwebsoft.com" target="_blank">BestWebSoft</a> and we'll add it to the plugin. You can download the latest version of the program for work with PO and MO files <a href="http://www.poedit.net/download.php" target="_blank">Poedit</a>.

= Technical support =

Dear users, our plugins are available for free download. If you have any questions or recommendations regarding the functionality of our plugins (existing options, new options, current issues), please feel free to contact us. Please note that we accept requests in English only. All messages in another languages won't be accepted.

If you notice any bugs in the plugins, you can notify us about this and we'll investigate and fix the issue then. Your request should contain URL of the website, issues description and WordPress admin panel credentials.
Moreover we can customize the plugin according to your requirements. It's a paid service (as a rule it costs $40, but the price can vary depending on the amount of the necessary changes and their complexity). Please note that we could also include this or that feature (developed for you) in the next release and share with the other users then. 
We can fix some things for free for the users who provide translation of our plugin into their native language (this should be a new translation of a certain plugin, you can check available translations on the official plugin page).

== Installation ==

1. Upload the folder `Contact Form Pro` to the directory `/wp-content/plugins/`.
2. Activate the plugin using the 'Plugins' menu in your WordPress admin panel.
3. You can adjust the necessary settings using your WordPress admin panel in "Settings" > "Contact Form Pro".
4. Create a page or a post and insert the shortcode [contact_form] into the text.

== Frequently Asked Questions ==

= Where can I find the settings to adjust the plugin work after activation? =

You can find the link to the Settings Page in the Plugin menu. 

= After the plugin installation I haven't adjusted the settings. What is the default email address used for a contact via the form? =

The address specified during WordPress installation will be used by the Contact Form Pro plugin as the default one.

= How can I add Contact Form Pro to my website? =

You should put the shortcode [contact_form] into your page or post.

= I chose a user via the plugin settings and got this error: "Please enter a valid email address. Settings are not saved." =

This means that you made a syntax error.

= How to use some other language files with the Contact Form Pro? = 

Here is an example for the German language files.

1. In order to use another language for WordPress it is necessary to switch the WP version to the required language and in the configuration wp file - `wp-config.php` in the line `define('WPLANG', '');` you should type `define('WPLANG', 'de_DE');`. If everything is done properly admin panel will be in German.
2. Make sure that there are the files `de_DE.po` and `de_DE.mo` in the plugin (in the languages folder which is in the root of the plugin).
3. If there are no such files you should copy the other files from this folder (for example, for the Russian or Italian language) and rename them (you should type `de_DE` instead of `ru_RU` in both files).
4. The files can be edited with the help of the program Poedit - http://www.poedit.net/download.php - please download this program, install it, open the file (the necessary language file) with this program and for each line in English write translation in German.
5. If everything is done properly all lines will be in German in the admin panel and in the front-end.

= How to add the contact form not in English? =

1. Add a language in the block "Language settings for the field names in the form" on the plugin settings page.
2. Mark the check box (if it's not marked yet) in the block  "Change the names of the contact form fields and error messages", choose the necessary tab and fill in the fields. Choose the necessary tab in the block "Action after email is sent" as well and fill in the field. Save the changes.
3. You will see the shortcode under the tab with the necessary language. Please paste that shortcode to the page or post. 

== Screenshots ==

1. Contact Form Pro display.
2. Contact Form Pro display with additional fields.
3. Plugin settings in WordPress admin panel.
4. Plugin settings in WordPress admin panel with additional fields.
5. Plugin extra settings in WordPress admin panel.
6. Widget settings for using shortcode in the sidebar.
7. The example of Contact Form Pro Plugin usage on client's site.
8. The example of Contact Form Pro Plugin usage on client's site.
9. The example of Contact Form Pro Plugin usage on client's site.
10. The example of Contact Form Pro Plugin usage on client's site.
11. The example of Contact Form Pro Plugin usage on client's site.
12. The example of Contact Form Pro Plugin usage on client's site.

== Changelog ==

= V1.05 - 05.08.2013 =
* Update : We updated all functionality for wordpress 3.6
* Bugfix : We fixed the email validation bug.
* Update : We removed displaying of additional info in the copy of email to the sender.

= V1.04 - 30.07.2013 =
* NEW : Added an ability to use diffrent shortcodes.
* Update : The Swedish language file is updated.
* Update : The Brazilian Portuguese language file is updated.

= V1.03 - 24.07.2013 =
* Bugfix : We fixed the displaying bug.

= V1.02 - 23.07.2013 =
* NEW : The setting of displaying Captcha is added.
* NEW : Added an ability to view and send system information by mail.
* Update : We updated all functionality for wordpress 3.5.2
* NEW : The Catalan language file is added.
* Update : The French language file is updated.

= V1.01 - 25.06.2013 =
* NEW : The Finnish language file is added to the plugin.

= V1.0 - 24.06.2013 =
* NEW : You can change the Contact Form CSS
* NEW : You can add a placeholder
* NEW : You can add tooltips for each field
* NEW : You can use JavaScript for the form validation with highlighting option

== Upgrade Notice ==

= V1.05 =
We updated all functionality for wordpress 3.6 We fixed the email validation bug. We removed displaying of additional info in the copy of email to the sender.

= V1.04 =
Added an ability to use diffrent shortcodes.: The Swedish language file is updated. The Brazilian Portuguese language file is updated.

= V1.03 =
We fixed the displaying bug.

= V1.02 =
The setting of displaying Captcha is added. Added an ability to view and send system information by mail. We updated all functionality for wordpress 3.5.2 The Catalan language file is added. The French language file is updated.

= V1.01 =
The Finnish language file is added to the plugin.

= V1.0 =
You can change the Contact Form CSS. You can add a placeholder. You can add tooltips for each field. You can use JavaScript for the form validation with highlighting option